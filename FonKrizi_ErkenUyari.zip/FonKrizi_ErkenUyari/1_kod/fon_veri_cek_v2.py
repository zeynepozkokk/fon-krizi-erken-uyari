# fon_veri_cek_v2.py  -  TEFAS'taki TUM yatirim fonlarinin gunluk fiyat gecmisini ceker
# Yarida kesilirse tekrar calistir: kaldigi yerden devam eder.
import json, os, time
import pandas as pd
import requests

KOK = "https://www.tefas.gov.tr"
BASLANGIC = "2025-07-01"
PERIYOD = 36                      # TEFAS'in kabul ettigi ay secenekleri: 1,3,6,12,36,60
EK_KODLAR = ["TLY", "THF"]        # Haberlerde gecen kriz fonlari (listede yoksa ayrica denenir)
HAM_KLASOR = "ham_veri"
os.makedirs(HAM_KLASOR, exist_ok=True)

s = requests.Session()
s.headers.update({
    "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 Chrome/124 Safari/537.36",
    "Content-Type": "application/json", "Accept": "application/json, text/plain, */*"})

def post(uc, govde):
    r = s.post(KOK + uc, json=govde, timeout=30)
    r.raise_for_status()
    return r.json().get("resultList") or []

# 1) Fon listesini al (getiri bilgileriyle birlikte)
print("1/3 Fon listesi aliniyor...")
liste = post("/api/funds/fonGetiriBazliBilgiGetir", {
    "dil": "TR", "fonTipi": "YAT", "kurucuKodu": None, "sfonTurKod": None, "fonTurAciklama": None,
    "islem": 1, "fonTurKod": None, "fonGrubu": None, "donemGetiri1a": "1", "donemGetiri3a": "1",
    "donemGetiri6a": "1", "donemGetiri1y": "1", "donemGetiriyb": "1", "donemGetiri3y": "1",
    "donemGetiri5y": "1", "basTarih": None, "bitTarih": None, "calismaTipi": 2, "getiriOrani": "1"})
pd.DataFrame(liste).to_csv("fon_listesi.csv", index=False, encoding="utf-8-sig")
kodlar = [r["fonKodu"] for r in liste if r.get("fonKodu")]
kodlar += [k for k in EK_KODLAR if k not in kodlar]
print(f"   {len(kodlar)} fon bulundu -> fon_listesi.csv")

# 2) Her fonun fiyat gecmisini cek (her fon ayri dosya = kaldigi yerden devam)
print("2/3 Fiyat gecmisleri cekiliyor (uzun surebilir, bilgisayari uyutma)...")
basla = time.time()
for i, kod in enumerate(kodlar, 1):
    yol = os.path.join(HAM_KLASOR, f"{kod}.json")
    if os.path.exists(yol):
        continue
    try:
        veri = post("/api/funds/fonFiyatBilgiGetir", {"fonKodu": kod, "dil": "TR", "periyod": PERIYOD})
        json.dump(veri, open(yol, "w"), ensure_ascii=False)
    except Exception as e:
        print(f"   HATA {kod}: {e}")
    if i % 25 == 0:
        gecen = time.time() - basla
        print(f"   {i}/{len(kodlar)} fon tamam  (~{gecen/60:.1f} dk gecti)")
    time.sleep(0.4)

# 3) Hepsini tek tabloda birlestir
print("3/3 Birlestiriliyor...")
parcalar = []
for dosya in os.listdir(HAM_KLASOR):
    satirlar = json.load(open(os.path.join(HAM_KLASOR, dosya)))
    if satirlar:
        parcalar.append(pd.DataFrame(satirlar))
tum = pd.concat(parcalar, ignore_index=True)
tum["tarih"] = pd.to_datetime(tum["tarih"]).dt.date.astype(str)
tum = tum[tum["tarih"] >= BASLANGIC]
tum.to_csv("tefas_tum_fonlar.csv", index=False, encoding="utf-8-sig")
print(f"BITTI! {len(tum):,} satir, {tum['fonKodu'].nunique()} fon -> tefas_tum_fonlar.csv")
print("Sutunlar:", list(tum.columns))
