# analiz.py - Sinyaller + yapay zeka (Isolation Forest) ile fon risk skoru
import json, os
import numpy as np, pandas as pd
from sklearn.ensemble import IsolationForest

KRIZ_BASI = "2026-09-16"      # Ilk temerrut tarihi. Skorlar SADECE bu tarihten onceki veriyle hesaplanir.
EGITIM_BITIS = "2026-03-01"   # Model "normal"i bu tarihe kadarki veriden ogrenir
PENCERE = 60

rows = []
for f in os.listdir("ham_veri"):
    rows += json.load(open(os.path.join("ham_veri", f)))
df = pd.DataFrame(rows)[["fonKodu", "tarih", "fiyat"]]
df["tarih"] = pd.to_datetime(df["tarih"].str[:10])
df = df[(df["fiyat"] > 0) & (df["tarih"] < KRIZ_BASI)]
df = df.drop_duplicates(["fonKodu", "tarih"]).sort_values(["fonKodu", "tarih"])
liste = pd.read_csv("fon_listesi.csv")[["fonKodu", "fonUnvan", "fonTurAciklama", "riskDegeri"]]
kriz = pd.read_csv("kriz_fonlari.csv")
df = df.merge(liste, on="fonKodu", how="left")
df["fonTurAciklama"] = df["fonTurAciklama"].fillna("Bilinmiyor")
df["kriz_fonu"] = df["fonKodu"].isin(kriz["kod"])

df["getiri"] = df.groupby("fonKodu")["fiyat"].pct_change()
df = df[df["getiri"].abs() < 0.3]
df["kat_getiri"] = df.groupby(["fonTurAciklama", "tarih"])["getiri"].transform("median")
df["fazla_getiri"] = df["getiri"] - df["kat_getiri"]

g = df.groupby("fonKodu")
rol = lambda col, fn, w=PENCERE: g[col].transform(lambda s: getattr(s.rolling(w, min_periods=40), fn)())
df["s1_kopuk_getiri"]   = rol("fazla_getiri", "sum")                                   # grubundan ne kadar ayristi
df["s2_puruzsuzluk"]    = rol("fazla_getiri", "mean") / (rol("fazla_getiri", "std") + 1e-6)  # grubuna gore "hic dusmeden" yukselis
df["s3_pozitif_gun"]    = g["getiri"].transform(lambda s: (s > 0).rolling(PENCERE, min_periods=40).mean())
df["s4_oynaklik"]       = rol("getiri", "std")
OZ = ["s1_kopuk_getiri", "s2_puruzsuzluk", "s3_pozitif_gun", "s4_oynaklik"]
v = df.dropna(subset=OZ).copy()

model = IsolationForest(n_estimators=300, contamination=0.01, random_state=42)
egitim = v[v["tarih"] < EGITIM_BITIS]
model.fit(egitim[OZ])
v["ham"] = -model.score_samples(v[OZ])
lo, hi = np.percentile(-model.score_samples(egitim[OZ]), [50, 99.9])
v["risk_skoru"] = np.clip((v["ham"] - lo) / (hi - lo) * 100, 0, 100).round(1)
# Tek gunluk sicramalari degil, 10 gun boyunca suren riski say
v["risk_skoru_10g"] = v.groupby("fonKodu")["risk_skoru"].transform(lambda s: s.rolling(10, min_periods=5).mean()).round(1)
v["alarm"] = np.select([v["risk_skoru_10g"] >= 70, v["risk_skoru_10g"] >= 50], ["Kirmizi", "Sari"], "Yesil")

v["tarih"] = v["tarih"].dt.date
v[["tarih", "fonKodu", "fonUnvan", "fonTurAciklama", "riskDegeri", "kriz_fonu", "fiyat", "getiri",
   "fazla_getiri"] + OZ + ["risk_skoru", "risk_skoru_10g", "alarm"]].to_csv("fon_gunluk_risk.csv", index=False, encoding="utf-8-sig")

# Degerlendirme
son = v[v["tarih"] == v["tarih"].max()]
print("Fon sayisi:", v.fonKodu.nunique(), "| Kriz fonu:", v[v.kriz_fonu].fonKodu.nunique(), "| Son gun:", v.tarih.max())
print("\n15 Eylul'de KIRMIZI alarmdaki fonlar:", (son.alarm == "Kirmizi").sum(), "/", len(son))
print(son.sort_values("risk_skoru_10g", ascending=False)[["fonKodu", "fonUnvan", "kriz_fonu", "risk_skoru_10g"]].head(20).to_string())
print("\nKriz fonlari - ilk kirmizi alarm (2026):")
for k, gr in v[v.kriz_fonu].groupby("fonKodu"):
    gr26 = gr[gr["tarih"] >= pd.Timestamp("2026-01-01").date()]
    ilk = gr26[gr26.alarm == "Kirmizi"]["tarih"].min()
    hafta = (pd.Timestamp(KRIZ_BASI) - pd.Timestamp(ilk)).days / 7 if pd.notna(ilk) else None
    sira = (son["risk_skoru_10g"] > son.loc[son.fonKodu == k, "risk_skoru_10g"].max()).sum() + 1
    print(f"  {k}: ilk kirmizi {ilk} -> {hafta and round(hafta,1)} hafta once | 15 Eylul skor siralamasi: {sira}/{len(son)}")
